﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICP.KeyExchange.TestLibrary.Models
{
    public class AuthorizationApiEncryptResult : BaseResult
    {
        public string EncData { get; set; }
    }
}
