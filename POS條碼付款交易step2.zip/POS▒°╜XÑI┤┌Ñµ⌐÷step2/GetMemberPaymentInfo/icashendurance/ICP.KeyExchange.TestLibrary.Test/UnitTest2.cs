﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ICP.KeyExchange.TestLibrary.Test
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
